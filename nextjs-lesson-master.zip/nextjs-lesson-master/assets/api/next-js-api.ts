import {AxiosInstance} from 'axios';

export class NextJsApi {
    constructor(private instance: AxiosInstance) {}
}